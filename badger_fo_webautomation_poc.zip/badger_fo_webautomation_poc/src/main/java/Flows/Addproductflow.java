package Flows;

import org.openqa.selenium.WebDriver;

public class Addproductflow {
//	public static void enterEmail(WebDriver driver, String vickyreddy0519@gmail.com) {
//		driver.findElement(email1).sendKeys(vickyreddy0519@gmail.com);
//	
//	}
//	
//	public void enterpass(WebDriver driver, String vicky123) {
//		driver.findElement(pass).sendKeys(vicky123);
//		driver.findElement(pass).click();
//	}
//		public void entesubmit(WebDriver driver, String submitq) {
//	    driver.findElement(submit).click();
//	}

}
