package automationPractice;

public class Sample {

	
	private void psv() {
		// TODO Auto-generated method stub

	}
}
